export enum BackgroundTypeEnum {
    LIGHTCORAL= 'LightCoral',
    WHITE= 'White'
}
