export interface UserModel {
    id: string;
    name: string
    phone: string
}
